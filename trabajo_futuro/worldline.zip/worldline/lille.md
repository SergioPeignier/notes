# [Maps](https://www.google.fr/maps/place/Carvin/@50.5410961,3.0568649,1565m/data=!3m1!1e3!4m5!3m4!1s0x47dd2d661fb0ebdf:0x6a387ea944455764!8m2!3d50.491515!4d2.958107)

# Houses:
+ [102 m^2 Carvin 199.000 €](http://www.pap.fr/annonce/immobilier-vente-maison-lille-59-g43627-4-r412400703)
+ [85 m^2 Oignies 166.500 €](http://www.pap.fr/annonce/immobilier-vente-maison-lille-59-g43627-4-r413301561)
+ [100 m^2 Phalempin 200.000 €](http://www.pap.fr/annonce/maison-a-vendre-lille-59-g43627-3-r414400644#dialog_carte)
+ [107 m^2 Allennes-Les-Marais 210.000 €](https://www.google.fr/maps/place/Allennes-les-Marais/@50.5405631,2.8051631,11z/data=!4m5!3m4!1s0x47dd2c8af184849f:0x40af13e81647880!8m2!3d50.537157!4d2.952225)
+ [150 m^2 Tourcoing 137.900 €](http://www.pap.fr/annonce/maison-a-vendre-lille-59-g43627-3-r412901636)
+ [87 m^2 Roubaix 135.000 €](http://www.pap.fr/annonce/ventes-maisons-lille-59-g43627-2-r414801228)
+ [90 m^2 Roubaix 123.000 €](http://www.pap.fr/annonce/ventes-maisons-lille-59-g43627-2-r414700699)
+ [3 pièces 70m^2 Lille](http://www.seloger.com/annonces/achat/maison/lille-59/fives/116335267.htm#anchorBar_1403515239_anchor_zone)
+ [75 m² environ 4 pièces 118 000](http://www.logic-immo.com/detail-vente-fe058721-29dd-13ae-cc1e-51f9fd3830b9.htm?mea=alaune1)
+ [69 m^2 5 pièces Seclin (59113) 104 000 €](http://www.logic-immo.com/detail-vente-c92a7446-3e70-964c-ea34-33e4d7050431.htm)
+ [55 m² environ4 pièces 124 000 €](http://www.logic-immo.com/detail-vente-47317727-5291-b222-e780-8f7dd397629f.htm)
+ [95 m² 4 pièces Seclin (59113) 140 000 €](http://www.logic-immo.com/detail-vente-3414a8b6-c72d-51c4-7053-4f48b2f2884d.htm)
# Sites web
+ http://www.pap.fr/annonce/
+ http://www.seloger.com
+ http://www.logic-immo.com