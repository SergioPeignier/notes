http://www.entreparticuliers.com/annonces-immobilieres/location/appartement/seclin-59113
http://www.logic-immo.com/detail-location-881a43f8-f5d8-ef10-04d2-e127bbd1947e.htm
http://www.logic-immo.com/detail-location-092cd8ff-8aab-7ecb-b26a-4aede7243464.htm
http://www.seloger.com/annonces/locations/appartement/seclin-59/centre/114988025.htm
http://www.logic-immo.com/detail-location-66a88035-3197-1360-9fb1-137f4b70efbe.htm
http://www.seloger.com/annonces/locations/appartement/wattignies-59/arbrisseau-ouest/116363429.htm

https://www.google.fr/maps/dir/50.58227,3.0365795/Worldline,+Zone+Industrielle+A,+Rue+de+la+Pointe,+59113+Seclin/@50.5534269,3.0181192,14.4z/data=!4m9!4m8!1m0!1m5!1m1!1s0x47c2d487ae5eab19:0xe165d56128b4edea!2m2!1d3.0292016!2d50.5673783!
https://www.google.fr/maps/place/Worldline/@50.5673783,3.0270129,17z/data=!3m1!4b1!4m5!3m4!1s0x47c2d487ae5eab19:0xe165d56128b4edea!8m2!3d50.5673783!4d3.0292016
https://www.google.fr/maps/search/séclin+Marcel+Paul/@50.5681656,3.0292352,17z/data=!3m1!4b1

https://www.voyages-sncf.com/billet-train?hid=P17
https://www.horairetrain.net/horaires-lille-seclin-20170323-0700.html
https://www.joursferies.fr/plan_metro/plan_metro_lille.php

